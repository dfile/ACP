#ifndef _TYPEDEFS_H_
#define _TYPEDEFS_H_

#define NUMFORM "%d"
#define UNUMFORM "%u"

typedef int number;
typedef unsigned int unumber;
#endif
