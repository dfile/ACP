#ifndef _TYPEDEFS_H_
#define _TYPEDEFS_H_

#define NUMFORM "%lld"
#define UNUMFORM "%llu"

typedef long long int number;
typedef unsigned long long int unumber;
#endif
