// Implementation of set_t

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "typedefs.h"
#include "set_t.h"

// Bare-bones initializer, just allocates memory and returns
set_t* setInit(void)
{
    return setInitWithLenAndZeroAndItems(0, 0, NULL);
}

// This is the initializer that should be used when making sets
set_t* setInitWithLenAndZero(unumber len, number zero)
{
    //byte *b = (byte *)calloc(len, sizeof(byte) * (len));
    // for some reason calloc can't allocate memory as large
    // as malloc can, so instead malloc the array and set
    // each index to be 0.
    //printf("malloc set items: "NUMFORM" bytes\n", sizeof(byte) * len);
    byte *b = (byte *)malloc(sizeof(byte) * (len));
    //number i;
    if (b == NULL) 
    {
        fprintf(stderr, "ERR: Couldn't malloc in setInitWithLenAndZero()\n");
    }
    else
    {
        memset(b, 0, len);
        //for (i = 0; i < len; i++)
        //{
        //    b[i] = 0;
        //}
    }
    set_t *s = setInitWithLenAndZeroAndItems(len, zero, b);
    return s;
}

// Use this initializer too
set_t* setInitWithRange(number low, number high)
{
    unumber len = high - low + 1;
    number zero;
    if (low <= 0)
    {
        zero = 0 - low;
    }
    else if (low > 0)
    {
        zero = 0 + low;
    }
    return setInitWithLenAndZero(len, zero);
}

// Designated initializer
set_t* setInitWithLenAndZeroAndItems(unumber len, number zero, byte *items)
{
    //printf("malloc set struct: %d bytes\n", sizeof(struct set_s));
    set_t *set = malloc(sizeof(struct set_s));
    setSetItems(set, items);
    setSetNumItems(set, 0);
    setSetLen(set, len);
    setSetZero(set, zero);
    return set;
}

// Uninitializer
void setDestroy(set_t *s)
{
    if (s == NULL) { return; }
    free(s->items);
    //printf("destroy set items\n");
    free(s);
    //printf("destroy set struct\n");
    s = NULL;
}

unumber setOffsetToZero(set_t *s, number n)
{
    if (setGetZero(s) <= 0)
    {
        return n - setGetZero(s);
    }
    else
    {
        return n + setGetZero(s);
    }
}

number setOffsetToNormal(set_t *s, unumber u)
{
    if (setGetZero(s) <= 0)
    {
        return u + setGetZero(s);
    }
    else
    {
        return u - setGetZero(s);
    }
}

byte setIsInRange(set_t *s, number n)
{
    n = setOffsetToZero(s, n);
    return (n >= 0 && n < setGetLen(s));
}

byte setSetItem(set_t *s, number n, byte b)
{
    if (s != NULL)
    {
        if (s->items != NULL)
        {
            if (setIsInRange(s, n))
            {
                unumber index = setOffsetToZero(s, n);
                s->items[index] = b;
            }
            else
            {
                fprintf(stderr, "ERR: "NUMFORM" is out of range of set in setSetItem()\n", n);
            }
        }
        else
        {
            fprintf(stderr, "ERR: items of set is NULL in setSetItem()\n");
            return -1;
        }
    }
    else
    {
        fprintf(stderr, "ERR: set is NULL in setSetItem()\n");
        return -1;
    }
    return 0;
}

//(byte *)malloc(sizeof(byte) * (len + zero)) 
byte* setGetItems(set_t *s)
{
    if (s != NULL) { return s->items; }
    else
    {
        fprintf(stderr, "ERR: set_t NULL in setGetItems()\n");
        return NULL;
    }
}

void setSetItems(set_t *s, byte *b)
{
    if (s != NULL) { 
        if (b == NULL) { fprintf(stderr, "ERR: Trying to set NULL items to set in setSetItems()\n"); }
        s->items = b;
    }
    else
    {
        fprintf(stderr, "ERR: Trying to set items of NULL set in setSetItems()\n");
    }
}

unumber setGetNumItems(set_t *s)
{
    if (s != NULL) { return s->num_items; }
    else
    {
        fprintf(stderr, "set_t NULL in setGetNumItems()");
        return 0;
    }
}

void setSetNumItems(set_t *s, unumber n)
{
    if (s != NULL) { s->num_items = n; }
    else
    {
        fprintf(stderr, "Trying to set num_items of NULL set in setSetNumItems()\n");
    }
}

unumber setGetLen(set_t *s)
{
    if (s != NULL) { return s->len; }
    else
    {
        fprintf(stderr, "set_t NULL in setGetLen()\n");
        return 0;
    }
}

void setSetLen(set_t *s, unumber len)
{
    if (s != NULL) { s->len = len; }
    else
    {
        fprintf(stderr, "Trying to set len of NULL set in setSetLen()\n");
    }
}

number setGetZero(set_t *s)
{
    if (s != NULL) { return s->zero; }
    else
    {
        fprintf(stderr, "set_t NULL in setGetZero()\n");
        return 0;
    }
}

void setSetZero(set_t *s, number zero)
{
    if (s != NULL)
    {
        s->zero = zero;
    }
    else
    {
        fprintf(stderr, "Trying to set zero of NULL set in setSetZero()\n");
        return;
    }
}

number setGetLowRange(set_t *s)
{
    return (0 - setGetZero(s));
}

number setGetHighRange(set_t *s)
{
    return (setGetLen(s) - 1 - setGetZero(s));
}

// XXX: pass in a buffer that it fills in rather than malloc
char* setGetRange(set_t *s)
{
    char *r = (char *)malloc(sizeof(char) * 30);
    sprintf(r, "["NUMFORM" to "NUMFORM"]", setGetLowRange(s), setGetHighRange(s));
    return r;
}

byte setExists(set_t *s, number e)
{
    if (s != NULL)
    {
        if (setGetItems(s) != NULL)
        {
            if (setIsInRange(s, e))
            {
                
                number index = setOffsetToZero(s, e);
                return setGetItems(s)[index];
            }
            else
            {
                char *range = setGetRange(s);
                fprintf(stderr, "ERR: "NUMFORM" is outside of bounds %s of byte array of set in setExists()\n", e, range);
                free(range);
            }
        }
        else
        {
            fprintf(stderr, "ERR: Can't check "NUMFORM" in NULL byte array of set in setExists()\n", e);
        }
    }
    else
    {
        fprintf(stderr, "ERR: Can't check "NUMFORM" in NULL set in setExists()\n", e);
    }
    return (byte)(-1);

}

number setAdd(set_t *s, number a)
{
    if (s != NULL)
    {
        if (setGetItems(s) != NULL)
        {
            //number index = setOffsetToZero(s, a);
            if (setIsInRange(s, a))
            {
                // increment num_items only if index doesn't exist (is 0)
                //printf("Adding "NUMFORM" at "NUMFORM" to set\n", a, index);
                setSetNumItems(s, (setExists(s, a) ? setGetNumItems(s) : (setGetNumItems(s) + 1)) );
                //XXX
                setSetItem(s, a, (byte)1);
                return 0;
            }
            else
            {
                char *range = setGetRange(s);
                fprintf(stderr, "ERR: "NUMFORM" is outside of bounds %s of byte array of set in setAdd()\n", a, range);
                free(range);
            }
        }
        else
        {
            fprintf(stderr, "ERR: Trying to add "NUMFORM" to NULL byte array of set in setAdd()\n", a);
        }
    }
    else
    {
        fprintf(stderr, "ERR: Trying to add "NUMFORM" to NULL set in setAdd()\n", a);
    }
    return -1;
}

number setRemove(set_t *s, number r)
{
    if (s != NULL)
    {
        if (setGetItems(s) != NULL)
        {
            //number index = setOffsetToZero(s, r);
            if (setIsInRange(s, r))
            {
                // decrement num_items only if index exists (is 1)
                printf("Removing "NUMFORM" at "NUMFORM" from set\n", r, setOffsetToZero(s, r));
                setSetNumItems(s, (setExists(s, r) ? setGetNumItems(s) - 1 : setGetNumItems(s)) );
                setSetItem(s, r, (byte)0);
                return 0;
            }
            else
            {
                char *range = setGetRange(s);
                fprintf(stderr, "ERR: "NUMFORM" is outside of bounds %s of byte array of set in setRemove()\n", r, setGetRange(s));
                free(range);
            }
        }
        else
        {
            fprintf(stderr, "ERR: Can't remove "NUMFORM" from NULL byte array of set in setRemove()\n", r);
        }
    }
    else
    {
        fprintf(stderr, "ERR: Can't remove "NUMFORM" from NULL set in setRemove()\n", r);
    }
    return -1;
}


void setPrintDefault(set_t *s)
{
    printf("Set items: [");
    unumber i = 0;
    for (i = 0; i < setGetLen(s); i++)
    {
        if (setExists(s, setOffsetToNormal(s, i)))
        {
            if (i + 1 == setGetLen(s))
            {
                printf(""NUMFORM"", i - setGetZero(s));
            }
            else
            {
                printf(""NUMFORM",", i - setGetZero(s));
            }
        }
    }
    printf("]\n");
}

void setPrintByteArray(set_t *s)
{
    printf("Set items: [\n");
    unumber i = 0;
    for (i = 0; i < setGetLen(s); i++)
    {
        printf(NUMFORM": "NUMFORM"\n", setOffsetToNormal(s, i), (number)(setExists(s, setOffsetToNormal(s, i))));
    }
    printf("]\n");
}

void setPrintVerbose(set_t *s)
{
    setPrintDefault(s);
    setPrintByteArray(s);
}

void setPrint(set_t *s, byte opt)
{
    if (s == NULL) { printf("Set is NULL\n"); }
    else
    {
        printf("Set num_items: "UNUMFORM"\n", setGetNumItems(s));
        printf("Set zero: "NUMFORM"\n", setGetZero(s));
        printf("Set len: "UNUMFORM"\n", setGetLen(s));
        char *range = setGetRange(s);
        printf("Set range: %s\n", range);
        free(range);

        if (setGetItems(s) == NULL) { printf("Set items: NULL\n"); }
        else
        {
            if (opt == 2) { setPrintVerbose(s); }
            else if (opt == 1) { setPrintByteArray(s); }
            // this is the default print method
            else if (opt == 0 || 1) { setPrintDefault(s); }
        }
    }
}

void setClear(set_t *s)
{
    if (s != NULL)
    {
        if (setGetItems(s) != NULL)
        {
            setSetNumItems(s, 0);
            //number i = 0;
            memset(setGetItems(s), 0, s->len);
            //for (i = 0; i < setGetLen(s); i++)
            //{
            //    setGetItems(s)[i] = (byte)0;
            //}
        }
    }
}
